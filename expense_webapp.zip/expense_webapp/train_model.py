"""
train_model.py
==============
Trains the two expense-prediction models (Linear Regression and Random Forest
Regression), then saves everything the web app needs:

    models/linear_model.pkl        - the trained Linear Regression pipeline
    models/random_forest_model.pkl - the trained Random Forest pipeline
    models/metrics.json            - R2, RMSE, MAE, F1 and feature importances
    models/options.json            - dropdown choices for the web form
    static/charts/*.png            - charts shown on the "Model Metrics" page

Run this ONCE before starting the app:

    python train_model.py

It expects the dataset 'expense_dataset_3000.csv' in this folder (or in a
'data' sub-folder).
"""

import os
import json
import datetime

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")              # draw charts to files, no pop-up window
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (mean_squared_error, mean_absolute_error, r2_score,
                             f1_score, precision_score, recall_score)

# ----------------------------------------------------------------------------
# Paths and settings
# ----------------------------------------------------------------------------
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR  = os.path.join(BASE_DIR, "models")
CHART_DIR  = os.path.join(BASE_DIR, "static", "charts")
DATA_PATHS = [os.path.join(BASE_DIR, "expense_dataset_3000.csv"),
              os.path.join(BASE_DIR, "data", "expense_dataset_3000.csv")]

TARGET   = "Amount_INR"
CAT_COLS = ["Category", "Payment_Method", "Day_of_Week"]   # text -> one-hot encoded
NUM_COLS = ["Year", "Month_Number", "Day"]                 # numbers -> used as-is
DROP_COLS = ["Transaction_ID", "Description", "Month", "Income_Expense", "Date"]
FEATURE_COLS = CAT_COLS + NUM_COLS                          # what the model needs

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(CHART_DIR, exist_ok=True)


def find_dataset():
    """Return the path of the dataset, or raise a helpful error."""
    for path in DATA_PATHS:
        if os.path.exists(path):
            return path
    raise FileNotFoundError(
        "Could not find 'expense_dataset_3000.csv'.\n"
        "Please put the CSV file in the same folder as this script "
        "(or in a 'data' sub-folder) and run again."
    )


def clean_dataframe(df):
    """Apply the exact same cleaning the notebook does."""
    df = df.copy()
    drop = [c for c in DROP_COLS if c in df.columns]
    df = df.drop(columns=drop)
    return df


def bucket_labels(amounts, low_cut, high_cut):
    """Turn amounts into 0=Low, 1=Medium, 2=High using two cut-offs."""
    return np.where(amounts <= low_cut, 0, np.where(amounts <= high_cut, 1, 2))


def main():
    print("=" * 60)
    print("EXPENSE PREDICTION - MODEL TRAINING")
    print("=" * 60)

    # ---------------------------------------------------------------- 1. Load
    data_path = find_dataset()
    print(f"\n[1/6] Loading data from: {data_path}")
    df = pd.read_csv(data_path)
    print(f"      Raw shape: {df.shape}")

    # ---------------------------------------------------------------- 2. Clean
    print("\n[2/6] Cleaning data ...")
    df = clean_dataframe(df)
    print(f"      Columns kept: {list(df.columns)}")
    print(f"      Missing values: {df.isnull().sum().sum()}")

    X = df[FEATURE_COLS]
    y = df[TARGET]

    # ---------------------------------------------------------------- 3. Split
    print("\n[3/6] Splitting 80% train / 20% test ...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42)
    print(f"      Train: {X_train.shape[0]} rows | Test: {X_test.shape[0]} rows")

    # Preprocessing recipe: one-hot encode text, keep numbers, ignore the rest.
    preprocessor = ColumnTransformer(transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT_COLS),
        ("num", "passthrough", NUM_COLS),
    ])

    # ---------------------------------------------------------------- 4. Train
    print("\n[4/6] Training models ...")
    models = {
        "linear_regression": LinearRegression(),
        "random_forest": RandomForestRegressor(
            n_estimators=200, random_state=42, n_jobs=-1),
    }

    # Bucket cut-offs (thirds of the actual amounts) for the F1 score.
    low_cut, high_cut = y.quantile([1 / 3, 2 / 3]).values

    metrics = {}
    predictions = {}

    for name, model in models.items():
        pipe = Pipeline(steps=[("preprocessor", preprocessor), ("regressor", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        predictions[name] = pred

        y_test_bucket = bucket_labels(y_test.values, low_cut, high_cut)
        pred_bucket   = bucket_labels(pred, low_cut, high_cut)

        metrics[name] = {
            "r2":        round(float(r2_score(y_test, pred)), 4),
            "rmse":      round(float(np.sqrt(mean_squared_error(y_test, pred))), 2),
            "mae":       round(float(mean_absolute_error(y_test, pred)), 2),
            "f1_macro":  round(float(f1_score(y_test_bucket, pred_bucket, average="macro")), 4),
            "precision": round(float(precision_score(y_test_bucket, pred_bucket, average="macro")), 4),
            "recall":    round(float(recall_score(y_test_bucket, pred_bucket, average="macro")), 4),
        }
        print(f"      {name:20s}  R2={metrics[name]['r2']:.4f}  "
              f"RMSE=Rs {metrics[name]['rmse']:.2f}  MAE=Rs {metrics[name]['mae']:.2f}")

        # Save the fitted pipeline so the web app can load it later.
        import joblib
        joblib.dump(pipe, os.path.join(MODEL_DIR, f"{name}.pkl"))

    # ---------------------------------------------------------------- 5. Charts
    print("\n[5/6] Drawing charts ...")

    # (a) Model comparison bar chart
    fig, ax = plt.subplots(figsize=(7, 4))
    labels = ["Linear\nRegression", "Random\nForest"]
    r2s = [metrics["linear_regression"]["r2"], metrics["random_forest"]["r2"]]
    bars = ax.bar(labels, r2s, color=["tab:blue", "tab:green"])
    ax.set_ylabel("R² score (higher is better)")
    ax.set_title("Model comparison - R² on the test set")
    ax.set_ylim(0, 1)
    for b, v in zip(bars, r2s):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.02, f"{v:.3f}", ha="center")
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "r2_comparison.png"), dpi=110)
    plt.close()

    # (b) Predicted vs Actual scatter (both models)
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    for ax, (name, colour) in zip(axes, [("linear_regression", "tab:blue"),
                                         ("random_forest", "tab:green")]):
        ax.scatter(y_test, predictions[name], alpha=0.4, s=12, color=colour)
        ax.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()],
                "r--", label="perfect prediction")
        ax.set_xlabel("Actual Amount (Rs)")
        ax.set_ylabel("Predicted Amount (Rs)")
        ax.set_title(name.replace("_", " ").title())
        ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "predicted_vs_actual.png"), dpi=110)
    plt.close()

    # (c) Feature importance from the Random Forest
    rf_pipe = joblib.load(os.path.join(MODEL_DIR, "random_forest.pkl"))
    feature_names = rf_pipe.named_steps["preprocessor"].get_feature_names_out()
    importances = pd.Series(
        rf_pipe.named_steps["regressor"].feature_importances_, index=feature_names
    ).sort_values(ascending=False)
    top10 = importances.head(10)
    fig, ax = plt.subplots(figsize=(8, 5))
    top10.sort_values().plot(kind="barh", ax=ax, color="tab:green")
    ax.set_xlabel("Importance")
    ax.set_title("What drives the predicted expense? (Random Forest)")
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "feature_importance.png"), dpi=110)
    plt.close()

    # ---------------------------------------------------------------- 6. Save
    print("\n[6/6] Saving metrics and options ...")
    metrics_payload = {
        "models": metrics,
        "feature_importance": {k: round(float(v), 5) for k, v in importances.items()},
        "buckets": {"low_cut": round(float(low_cut), 2),
                    "high_cut": round(float(high_cut), 2)},
        "n_train": int(X_train.shape[0]),
        "n_test": int(X_test.shape[0]),
        "trained_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
        json.dump(metrics_payload, f, indent=2)

    options_payload = {
        "Category": sorted(df["Category"].unique().tolist()),
        "Payment_Method": sorted(df["Payment_Method"].unique().tolist()),
        "Day_of_Week": sorted(df["Day_of_Week"].unique().tolist()),
        "Month_Number": sorted(df["Month_Number"].unique().tolist()),
        "Year": sorted(df["Year"].unique().tolist()),
    }
    with open(os.path.join(MODEL_DIR, "options.json"), "w") as f:
        json.dump(options_payload, f, indent=2)

    print("\nDone! Saved models and charts. You can now run:  python app.py")
    print("=" * 60)


if __name__ == "__main__":
    main()
