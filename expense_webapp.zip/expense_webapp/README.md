# Expense Predictor — a Machine Learning Web Application

A complete web app that predicts how much a transaction will cost, using two
regression models trained on your expense dataset:

- **Linear Regression**
- **Random Forest Regression**

It has three pages:

| Page | What it does |
|------|--------------|
| **Predict** | Fill in a form for one transaction and get the predicted amount from both models |
| **Batch Upload** | Upload a CSV and predict every row at once, then download the results |
| **Model Metrics** | Shows R², RMSE, MAE and F1 scores, plus charts and feature importance |

---

## 1. What you need

- A Windows computer
- Python installed (version 3.9 or newer)
- Your `expense_dataset_3000.csv` file

If you don't have Python yet: go to **python.org/downloads**, download the
installer, and **tick the box "Add Python to PATH"** during installation. This
box is important — without it, the `python` command will not work.

---

## 2. Set up the project (do this once)

Open the project folder in **Command Prompt** or **PowerShell**
(File Explorer → right-click inside the folder → *Open in Terminal*),
then run these commands one at a time:

```bat
:: 1. Create an isolated environment for this project
python -m venv venv

:: 2. Activate it (you will see "(venv)" appear at the start of the line)
venv\Scripts\activate

:: 3. Install the libraries the project needs
pip install -r requirements.txt
```

> **Why a "venv"?** It is a private toolbox just for this project, so installing
> these libraries does not affect anything else on your computer.

---

## 3. Train the models (do this once)

Make sure `expense_dataset_3000.csv` is in this same folder, then run:

```bat
python train_model.py
```

You will see the training progress and the scores printed in the terminal, for example:

```
linear_regression    R2=0.9416  RMSE=Rs 567.46  MAE=Rs 348.92
random_forest        R2=0.9290  RMSE=Rs 625.73  MAE=Rs 364.53
```

This creates:

```
models/linear_regression.pkl      (the trained Linear Regression model)
models/random_forest.pkl          (the trained Random Forest model)
models/metrics.json               (the scores shown on the Metrics page)
models/options.json               (the dropdown choices for the form)
static/charts/*.png               (the charts on the Metrics page)
```

---

## 4. Run the web app

```bat
python app.py
```

You will see a line like `Running on http://127.0.0.1:5000`. Open that address
in your browser:

**http://127.0.0.1:5000**

To stop the app, go back to the terminal and press **Ctrl + C**.

---

## 5. How to use each page

- **Predict** — choose a category, payment method and day, then press
  *Predict expense*. Both models return an estimate in rupees, and the model with
  the lower error is tagged "Best model".
- **Batch Upload** — click *Choose file*, pick a CSV that has the columns
  `Category, Payment_Method, Day_of_Week, Year, Month_Number, Day`, and press
  *Upload & predict*. Your original dataset works as-is. A **Download results**
  button then gives you a new CSV with two extra prediction columns.
- **Model Metrics** — see how accurate the models are and what drives the predictions.

---

## 6. Project structure

```
expense_webapp/
├── app.py                  the Flask web server (all the routes/pages)
├── train_model.py          trains the models and saves them
├── requirements.txt        the list of libraries to install
├── README.md               this file
├── expense_dataset_3000.csv  your data (place it here)
├── templates/              the HTML pages
│   ├── base.html           shared layout (header, footer, messages)
│   ├── index.html          the Predict page
│   ├── batch.html          the Batch Upload page
│   └── metrics.html        the Model Metrics page
├── static/
│   ├── style.css           the styling for every page
│   └── charts/             charts created by train_model.py
├── models/                 saved models (created by train_model.py)
└── uploads/                batch result files (created when you use Batch Upload)
```

---

## 7. How it works (the short version)

1. `train_model.py` reads the CSV, cleans it, splits it 80% train / 20% test,
   and trains both models.
2. Each model is saved as a `.pkl` file using `joblib` (Python's way of saving objects).
3. When the app starts, `app.py` loads those `.pkl` files into memory.
4. When you submit the form, `app.py` builds a one-row table and calls
   `model.predict(...)` on it, then shows the result in the page.

---

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized` | Python isn't on PATH. Reinstall and tick *Add Python to PATH*. |
| `No module named flask` | You forgot to run `pip install -r requirements.txt`, or the venv isn't active. |
| Page says *models are not trained* | Run `python train_model.py` first. |
| `Address already in use` | Another app is on port 5000. Change the port in `app.py` (last line) to `port=5001`. |
| Charts are missing on the Metrics page | Re-run `python train_model.py`; it creates the charts. |

---

## 9. Ideas to take it further

- Add user login so each person sees only their own predictions.
- Store predictions in a database (e.g. SQLite) for history.
- Deploy it online for free (Render, PythonAnywhere, or Railway) so it has a public link.
- Try more models (`GradientBoostingRegressor`, `XGBoost`) and add them to the app.
