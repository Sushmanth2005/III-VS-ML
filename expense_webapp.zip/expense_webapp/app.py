"""
app.py
======
The Flask web application for expense prediction.

Pages:
    /            - single-transaction prediction form
    /predict     - handles the form (POST) and shows both models' predictions
    /batch       - upload a CSV file and predict every row at once
    /download/.. - download the batch prediction results
    /metrics     - model performance (R2, RMSE, MAE, F1) and charts

Start the app with:   python app.py
Then open:            http://127.0.0.1:5000
"""

import os
import json
import datetime

import joblib
import numpy as np
import pandas as pd
from flask import (Flask, render_template, request, redirect,
                   url_for, flash, send_from_directory)

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

TARGET       = "Amount_INR"
CAT_COLS     = ["Category", "Payment_Method", "Day_of_Week"]
NUM_COLS     = ["Year", "Month_Number", "Day"]
DROP_COLS    = ["Transaction_ID", "Description", "Month", "Income_Expense", "Date"]
FEATURE_COLS = CAT_COLS + NUM_COLS

app = Flask(__name__)
app.secret_key = "expense-predictor-secret-key"   # needed for flash messages


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def format_inr(amount):
    """Format a number using the Indian grouping system, e.g. 1234567.5 -> Rs 12,34,567.50"""
    amount = float(amount)
    whole = int(amount)
    paise = int(round((amount - whole) * 100))
    s = str(abs(whole))
    if len(s) > 3:
        last3 = s[-3:]
        rest = s[:-3]
        parts = []
        while len(rest) > 2:
            parts.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            parts.insert(0, rest)
        s = ",".join(parts) + "," + last3
    sign = "-" if whole < 0 else ""
    return f"Rs {sign}{s}.{paise:02d}"


app.jinja_env.filters["inr"] = format_inr


def load_artifacts():
    """Load the trained models and saved JSON files. Returns (models, metrics, options)."""
    needed = ["linear_regression.pkl", "random_forest.pkl", "metrics.json", "options.json"]
    missing = [f for f in needed if not os.path.exists(os.path.join(MODEL_DIR, f))]
    if missing:
        return None, None, None
    models = {
        "linear_regression": joblib.load(os.path.join(MODEL_DIR, "linear_regression.pkl")),
        "random_forest":     joblib.load(os.path.join(MODEL_DIR, "random_forest.pkl")),
    }
    with open(os.path.join(MODEL_DIR, "metrics.json")) as f:
        metrics = json.load(f)
    with open(os.path.join(MODEL_DIR, "options.json")) as f:
        options = json.load(f)
    return models, metrics, options


MODELS, METRICS, OPTIONS = load_artifacts()


def models_ready():
    return MODELS is not None


def bucket_name(amount, metrics):
    """Return 'Low', 'Medium' or 'High' for a predicted amount."""
    low = metrics["buckets"]["low_cut"]
    high = metrics["buckets"]["high_cut"]
    if amount <= low:
        return "Low"
    if amount <= high:
        return "Medium"
    return "High"


# ----------------------------------------------------------------------------
# Routes
# ----------------------------------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html",
                           options=OPTIONS or {},
                           ready=models_ready(),
                           active="home")


@app.route("/predict", methods=["POST"])
def predict():
    if not models_ready():
        flash("Models are not trained yet. Please run 'python train_model.py' first.", "error")
        return redirect(url_for("home"))

    try:
        # Read the values the user typed into the form.
        row = {
            "Category":       request.form.get("Category", "").strip(),
            "Payment_Method": request.form.get("Payment_Method", "").strip(),
            "Day_of_Week":    request.form.get("Day_of_Week", "").strip(),
            "Year":           int(request.form.get("Year", 2024)),
            "Month_Number":   int(request.form.get("Month_Number", 1)),
            "Day":            int(request.form.get("Day", 1)),
        }
    except (TypeError, ValueError):
        flash("Please enter valid numbers for Year, Month and Day.", "error")
        return redirect(url_for("home"))

    # Build a one-row DataFrame in the exact column order the model expects.
    X_new = pd.DataFrame([row])[FEATURE_COLS]

    results = {}
    for name, model in MODELS.items():
        pred = float(model.predict(X_new)[0])
        results[name] = {
            "amount": format_inr(pred),
            "bucket": bucket_name(pred, METRICS),
            "raw": pred,
        }

    # Decide the "winner" = model with the lower RMSE.
    best = min(METRICS["models"],
               key=lambda k: METRICS["models"][k]["rmse"])

    return render_template("index.html",
                           options=OPTIONS,
                           ready=True,
                           active="home",
                           submitted=True,
                           row=row,
                           results=results,
                           best_model=best)


@app.route("/batch", methods=["GET", "POST"])
def batch():
    if not models_ready():
        flash("Models are not trained yet. Please run 'python train_model.py' first.", "error")
        return redirect(url_for("home"))

    if request.method == "GET":
        return render_template("batch.html", ready=True, active="batch")

    # ---- POST: a file was uploaded -----------------------------------------
    file = request.files.get("csv_file")
    if file is None or file.filename == "":
        flash("Please choose a CSV file to upload.", "error")
        return redirect(url_for("batch"))
    if not file.filename.lower().endswith(".csv"):
        flash("Only .csv files are supported.", "error")
        return redirect(url_for("batch"))

    try:
        df = pd.read_csv(file)
    except Exception as e:
        flash(f"Could not read that CSV file: {e}", "error")
        return redirect(url_for("batch"))

    # Make sure the columns we need are present.
    missing = [c for c in FEATURE_COLS if c not in df.columns]
    if missing:
        flash(f"Your CSV is missing these required columns: {', '.join(missing)}", "error")
        return redirect(url_for("batch"))

    # Predict every row with both models.
    X_batch = df[FEATURE_COLS]
    df_out = df.copy()
    df_out["Predicted_LinearRegression"] = np.round(MODELS["linear_regression"].predict(X_batch), 2)
    df_out["Predicted_RandomForest"]     = np.round(MODELS["random_forest"].predict(X_batch), 2)

    # Save the results so the user can download them.
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_name = f"predictions_{stamp}.csv"
    out_path = os.path.join(UPLOAD_DIR, out_name)
    df_out.to_csv(out_path, index=False)

    preview = df_out.head(15).to_dict(orient="records")
    columns = list(df_out.columns)

    return render_template("batch.html",
                           ready=True,
                           active="batch",
                           done=True,
                           n_rows=len(df_out),
                           columns=columns,
                           preview=preview,
                           download_name=out_name)


@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=True)


@app.route("/metrics")
def metrics():
    if not models_ready():
        flash("Models are not trained yet. Please run 'python train_model.py' first.", "error")
        return redirect(url_for("home"))

    # Top 10 features for the table on the page.
    top_features = sorted(METRICS["feature_importance"].items(),
                          key=lambda kv: kv[1], reverse=True)[:10]
    return render_template("metrics.html",
                           ready=True,
                           active="metrics",
                           m=METRICS["models"],
                           top_features=top_features,
                           meta=METRICS)


if __name__ == "__main__":
    if not models_ready():
        print("\n*** Models not found. Run 'python train_model.py' first. ***\n")
    # debug=True auto-reloads when you edit files; turn it off for a real deployment.
    app.run(debug=True, host="127.0.0.1", port=5000)
